export type City = {
  name: string;
  areaNumber: number;
  selected: boolean;
};
