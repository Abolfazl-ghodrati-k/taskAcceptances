import { IconType } from "react-icons";

export type IconProps = { onClick?: () => void; size?: number; color?: string; Icon: IconType };
