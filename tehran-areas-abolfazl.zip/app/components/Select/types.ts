export type SelectProps = {
    onSelect?: () => void
    onDeselect?: () => void
}