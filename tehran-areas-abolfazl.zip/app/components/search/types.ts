export type SearchProps = {
    search?: string
    city: string
}